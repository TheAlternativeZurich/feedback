<?php
use PHPUnit\Framework\TestCase;

class NothingTest extends TestCase
{
    public function testNothing()
    {
    }
}
